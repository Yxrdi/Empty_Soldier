import pygame, sys
import json
from boton import Boton
from fuente import obtener_fuente
from caja_de_texto import *
from constantes import *
from editar_usuario import*

class Menu:
    def __init__(self):
        pygame.init
        self.pantalla = pygame.display.set_mode((WIGHT, HEIGHT))
        pygame.display.set_caption(TITULO_JUEGO)
        
        self.fondo = pygame.image.load(FONDO)
        self.reloj = pygame.time.Clock()
        self.fuente = pygame.font.Font(TIPO_LETRA,FUENTE_BARRA)
        self.caja = Caja_De_Texto((WIGHT - ANCHO_BARRA)/2, HEIGHT/2, ANCHO_BARRA, ALTO_BARRA, self.fuente)
        self.ejecutando = True
        self.nombre_jugador = main()
        self.ventana_menu_principal()
        self.ventana_opciones()
        self.ventana_creditos()
        self.ventana_graficos()
        self.ventana_audio()
        self.ventana_iniciar_partida()
        self.borrar_partida()
        
    
    def ventana_controles(self):
        while True:
            
            pos_mouse_opciones= pygame.mouse.get_pos()
            
            self.pantalla.blit(self.fondo, (0, 0))
            
            texto_controles = obtener_fuente(45).render(CONTROLES, True, BLANCO)
            rect_controles = texto_controles.get_rect(center=(WIGHT/2, 150))
            self.pantalla.blit(texto_controles, rect_controles)
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_controles, rect_controles)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_opciones()

            pygame.display.update()
            
            
    def ventana_nombre_personajes(self):
        while True:
            pos_mouse_opciones= pygame.mouse.get_pos()

            self.pantalla.blit(self.fondo, (0, 0))
            
            
            texto_nombre = obtener_fuente(45).render(TITULO_NOMBRE_PERSONAJE, True, BLANCO)
            rect_nombre = texto_nombre.get_rect(center=(WIGHT/2, 300))
            self.pantalla.blit(texto_nombre, rect_nombre)
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_nombre, rect_nombre)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_menu_principal()
                
                self.caja.manejar_evento(evento)
            
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_RETURN:
                        self.ventana_menu_principal()
                
                

            self.caja.actualizar()
            self.caja.dibujar(self.pantalla)
            pygame.display.flip()
            self.reloj.tick(30)

            pygame.display.update()
            
            
    def ventana_borrar_partida(self):
        while True:
            pos_mouse_opciones= pygame.mouse.get_pos()

            self.pantalla.blit(self.fondo, (0, 0))
            
            
            texto_borrar_partida = obtener_fuente(45).render("DESEA BORRAR LA PARTIDA", True, BLANCO)
            rect_borrar_partida = texto_borrar_partida.get_rect(center=(WIGHT/2, 300))
            self.pantalla.blit(texto_borrar_partida, rect_borrar_partida)
            
            botones = [Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/2), texto_entrada="SI", 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                        Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.8), texto_entrada="NO", 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_borrar_partida, rect_borrar_partida)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.nombre_jugador = guardar_usuario("usuario1", "", ruta="datos.json")
                        self.ventana_menu_principal()
                    if botones[1].verificarEntrada(pos_mouse_opciones):
                        self.ventana_elegir_partida()

            pygame.display.update()
            
    def ventana_elegir_partida(self):
        while True:
            
            pos_mouse_opciones= pygame.mouse.get_pos()

            self.pantalla.blit(self.fondo, (0, 0))

            texto_elegir_partida = obtener_fuente(45).render("ELEGIR PARTIDA", True, BLANCO)
            rect_opciones = texto_elegir_partida.get_rect(center=(WIGHT/2, HEIGHT/4))
            self.pantalla.blit(texto_elegir_partida, rect_opciones)
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/2), texto_entrada=self.nombre_jugador,
                            fuente=obtener_fuente(25), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(1190, 700), texto_entrada="BORRAR PARTIDA",
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO)]


            self.pantalla.blit(texto_elegir_partida, rect_opciones)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)


            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_menu_principal()
                    if botones[1].verificarEntrada(pos_mouse_opciones):
                        pass
                    if botones[2].verificarEntrada(pos_mouse_opciones):
                        self.ventana_borrar_partida()

            pygame.display.update()
    
    def ventana_iniciar_partida(self):
        while True:
            self.nombre_jugador = main()
            if self.nombre_jugador == None or self.nombre_jugador == "":
                self.nombre_jugador = "PARTIDA NUEVA"
                self.ventana_nombre_personajes()
            else:
                self.nombre_jugador = main()
                self.ventana_elegir_partida()
                #self.ventana_nombre_personajes()
                
                
            
            
    def ventana_graficos(self):
        while True:
            
            pos_mouse_opciones= pygame.mouse.get_pos()

            self.pantalla.blit(self.fondo, (0, 0))
            
            texto_graficos = obtener_fuente(45).render(GRAFICOS, True, BLANCO)
            rect_graficos = texto_graficos.get_rect(center=(WIGHT/2, HEIGHT/4))
            self.pantalla.blit(texto_graficos, rect_graficos)
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_graficos, rect_graficos)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_opciones()

            pygame.display.update()
            
    def ventana_audio(self):
        while True:

            pos_mouse_opciones= pygame.mouse.get_pos()
            
            self.pantalla.blit(self.fondo, (0, 0))
            
            texto_audio = obtener_fuente(45).render(AUDIO, True, BLANCO)
            rect_audio = texto_audio.get_rect(center=(WIGHT/2, HEIGHT/4))
            self.pantalla.blit(texto_audio, rect_audio)
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_audio, rect_audio)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_opciones()

            pygame.display.update()
            
    def ventana_opciones(self):
        while True:
            
            pos_mouse_opciones= pygame.mouse.get_pos()

            self.pantalla.blit(self.fondo, (0, 0))

            texto_opciones = obtener_fuente(45).render(OPCIONES, True, BLANCO)
            rect_opciones = texto_opciones.get_rect(center=(WIGHT/2, HEIGHT/4))
            self.pantalla.blit(texto_opciones, rect_opciones)
            
            
            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/2), texto_entrada=GRAFICOS,
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, (HEIGHT/1.8)), texto_entrada=AUDIO,
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.636), texto_entrada=CONTROLES,
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO)]


            self.pantalla.blit(texto_opciones, rect_opciones)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)


            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_menu_principal()
                    if botones[1].verificarEntrada(pos_mouse_opciones):
                        self.ventana_graficos()
                    if botones[2].verificarEntrada(pos_mouse_opciones):
                        self.ventana_audio()
                    if botones[3].verificarEntrada(pos_mouse_opciones):
                        self.ventana_controles()

            pygame.display.update()

    def ventana_creditos(self):
        while True:

            pos_mouse_opciones= pygame.mouse.get_pos()
            
            self.pantalla.blit(self.fondo, (0, 0))
            
            texto_opciones = obtener_fuente(45).render(LISTA[0], True, BLANCO)
            rect_opciones = texto_opciones.get_rect(center=(WIGHT/2, HEIGHT/4))
            self.pantalla.blit(texto_opciones, rect_opciones)
            
            for i in range(1, len(LISTA)):
                texto_opciones = obtener_fuente(20).render(LISTA[i], True, BLANCO)
                rect_opciones = texto_opciones.get_rect(center=(WIGHT/2, 300 + i * 40))
                self.pantalla.blit(texto_opciones, rect_opciones)

            botones = [Boton(imagen=None, posicion=(50, 20), texto_entrada=RETROCEDER, 
                            fuente=obtener_fuente(20), color_base=BLANCO_OSCURO, color_hovering=BLANCO),]


            self.pantalla.blit(texto_opciones, rect_opciones)
            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_menu_principal()

            pygame.display.update()
    
    def ventana_menu_principal(self):
        while True:
            
            pos_mouse_opciones= pygame.mouse.get_pos()
            
            self.pantalla.blit(self.fondo, (0, 0))

            texto_menu = obtener_fuente(80).render(TITULO_JUEGO, True, BLANCO)
            rect_menu = texto_menu.get_rect(center=(WIGHT/2, HEIGHT/4))
            
            botones = [Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.6), texto_entrada=INICIAR_PARTIDA, 
                            fuente=obtener_fuente(25), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.44), texto_entrada=OPCIONES,
                                fuente=obtener_fuente(25), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.31), texto_entrada=CREDITOS,
                                fuente=obtener_fuente(25), color_base=BLANCO_OSCURO, color_hovering=BLANCO),
                       Boton(imagen=None, posicion=(WIGHT/2, HEIGHT/1.2), texto_entrada=SALIR_DEL_JUEGO, 
                                fuente=obtener_fuente(25), color_base=BLANCO_OSCURO, color_hovering=BLANCO)
                       ]

            self.pantalla.blit(texto_menu, rect_menu)

            for boton in botones:
                boton.cambiarColor(pos_mouse_opciones)
                boton.actualizar(self.pantalla)
            
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if botones[0].verificarEntrada(pos_mouse_opciones):
                        self.ventana_iniciar_partida()
                    if botones[1].verificarEntrada(pos_mouse_opciones):
                        self.ventana_opciones()
                    if botones[2].verificarEntrada(pos_mouse_opciones):
                        self.ventana_creditos()
                    if botones[3].verificarEntrada(pos_mouse_opciones):
                        pygame.quit()
                        sys.exit()

            pygame.display.update()










