import pygame
import sys

class Navegar:
    def __init__(self):
        pygame.init()

        # Pantalla
        self.ANCHO, self.ALTO = 800, 600
        self.pantalla = pygame.display.set_mode((self.ANCHO, self.ALTO))
        pygame.display.set_caption("Menú Ultra Completo Teclado/Mando/Mouse")

        # Colores
        self.BLANCO = (255, 255, 255)
        self.NEGRO = (0, 0, 0)
        self.AZUL = (50, 150, 255)
        self.GRIS = (200, 200, 200)

        # Fuente
        self.fuente = pygame.font.SysFont(None, 48)

        # Opciones de menú
        self.opciones_menu = ["Jugar", "Opciones", "Salir"]
        self.rectangulos_opciones = []
        self.indice_seleccionado = 0

        # Estado de la aplicación
        self.pantalla_actual = "menu"

        # Modo de entrada
        self.modo_entrada = "teclado"

        # Joystick
        pygame.joystick.init()
        self.mando = None
        if pygame.joystick.get_count() > 0:
            self.mando = pygame.joystick.Joystick(0)
            self.mando.init()

        self.reloj = pygame.time.Clock()

        # Variables para controlar el stick
        self.retardo_stick = 0

    def dibujar_menu(self):
        self.pantalla.fill(self.BLANCO)
        self.rectangulos_opciones = []

        for i, opcion in enumerate(self.opciones_menu):
            color = self.AZUL if i == self.indice_seleccionado else self.NEGRO
            texto = self.fuente.render(opcion, True, color)
            rect = texto.get_rect(center=(self.ANCHO // 2, self.ALTO // 2 + i * 70))
            self.pantalla.blit(texto, rect)
            self.rectangulos_opciones.append(rect)

        texto_modo = self.fuente.render(f"Modo: {self.modo_entrada.upper()}", True, self.GRIS)
        self.pantalla.blit(texto_modo, (10, 10))
        pygame.display.flip()

    def dibujar_juego(self):
        self.pantalla.fill((100, 200, 100))
        texto = self.fuente.render("¡Estás en el juego!", True, self.NEGRO)
        rect = texto.get_rect(center=(self.ANCHO // 2, self.ALTO // 2))
        self.pantalla.blit(texto, rect)
        pygame.display.flip()

    def dibujar_opciones(self):
        self.pantalla.fill((200, 200, 250))
        texto = self.fuente.render("Opciones", True, self.NEGRO)
        rect = texto.get_rect(center=(self.ANCHO // 2, self.ALTO // 2))
        self.pantalla.blit(texto, rect)
        pygame.display.flip()

    def seleccionar_opcion_menu(self):
        if self.indice_seleccionado == 0:
            self.pantalla_actual = "juego"
        elif self.indice_seleccionado == 1:
            self.pantalla_actual = "opciones"
        elif self.indice_seleccionado == 2:
            pygame.quit()
            sys.exit()

    def manejar_entrada_menu(self, evento):
        # Teclado
        if evento.type == pygame.KEYDOWN:
            self.modo_entrada = "teclado"
            if evento.key == pygame.K_DOWN:
                self.indice_seleccionado = (self.indice_seleccionado + 1) % len(self.opciones_menu)
            elif evento.key == pygame.K_UP:
                self.indice_seleccionado = (self.indice_seleccionado - 1) % len(self.opciones_menu)
            elif evento.key == pygame.K_RETURN:
                self.seleccionar_opcion_menu()

        # Ratón
        if evento.type == pygame.MOUSEMOTION:
            self.modo_entrada = "raton"
            posicion_raton = evento.pos
            for i, rect in enumerate(self.rectangulos_opciones):
                if rect.collidepoint(posicion_raton):
                    self.indice_seleccionado = i

        if evento.type == pygame.MOUSEBUTTONDOWN:
            self.modo_entrada = "raton"
            if evento.button == 1:  # Clic izquierdo
                self.seleccionar_opcion_menu()

        # Mando
        if evento.type == pygame.JOYHATMOTION:  # D-Pad
            self.modo_entrada = "mando"
            hat_x, hat_y = evento.value
            if hat_y == 1:
                self.indice_seleccionado = (self.indice_seleccionado - 1) % len(self.opciones_menu)
            elif hat_y == -1:
                self.indice_seleccionado = (self.indice_seleccionado + 1) % len(self.opciones_menu)

        if evento.type == pygame.JOYBUTTONDOWN:
            self.modo_entrada = "mando"
            if evento.button == 0:  # Botón A
                self.seleccionar_opcion_menu()

    def manejar_entrada_juego(self, evento):
        if evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
            self.pantalla_actual = "menu"
        if evento.type == pygame.JOYBUTTONDOWN and evento.button == 1:
            self.pantalla_actual = "menu"

    def manejar_entrada_opciones(self, evento):
        if evento.type == pygame.KEYDOWN and evento.key == pygame.K_ESCAPE:
            self.pantalla_actual = "menu"
        if evento.type == pygame.JOYBUTTONDOWN and evento.button == 1:
            self.pantalla_actual = "menu"

    def manejar_movimiento_stick(self):
        if self.mando:
            eje_y = self.mando.get_axis(1)  # Stick izquierdo vertical

            if abs(eje_y) > 0.5 and self.retardo_stick == 0:
                self.modo_entrada = "mando"
                if eje_y < 0:
                    self.indice_seleccionado = (self.indice_seleccionado - 1) % len(self.opciones_menu)
                else:
                    self.indice_seleccionado = (self.indice_seleccionado + 1) % len(self.opciones_menu)
                self.retardo_stick = 10  # Pequeño retardo

    def comprobar_conexion_mando(self, evento):
        if evento.type == pygame.JOYDEVICEADDED:
            print("Mando conectado")
            if not self.mando:
                self.mando = pygame.joystick.Joystick(evento.device_index)
                self.mando.init()

        if evento.type == pygame.JOYDEVICEREMOVED:
            print("Mando desconectado")
            self.mando = None

    def ejecutar(self):
        while True:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                self.comprobar_conexion_mando(evento)

                if self.pantalla_actual == "menu":
                    self.manejar_entrada_menu(evento)
                elif self.pantalla_actual == "juego":
                    self.manejar_entrada_juego(evento)
                elif self.pantalla_actual == "opciones":
                    self.manejar_entrada_opciones(evento)

            self.manejar_movimiento_stick()

            if self.retardo_stick > 0:
                self.retardo_stick -= 1

            if self.pantalla_actual == "menu":
                self.dibujar_menu()
            elif self.pantalla_actual == "juego":
                self.dibujar_juego()
            elif self.pantalla_actual == "opciones":
                self.dibujar_opciones()

            self.reloj.tick(60)

if __name__ == "__main__":
    Navegar().ejecutar()
