import json
import os

def cargar_datos_json(ruta="datos.json"):
    datos = {"usuarios": {}}
    if os.path.exists(ruta):
        with open(ruta, "r", encoding="utf-8") as archivo:
            try:
                contenido = json.load(archivo)
                if "usuarios" in contenido and isinstance(contenido["usuarios"], dict):
                    datos["usuarios"] = contenido["usuarios"]
            except json.JSONDecodeError:
                pass
    return datos

def guardar_datos_json(datos, ruta="datos.json"):
    with open(ruta, "w", encoding="utf-8") as archivo:
        json.dump(datos, archivo, ensure_ascii=False, indent=4)

def guardar_usuario(nombre_clave, texto, ruta="datos.json"):
    datos = cargar_datos_json(ruta)
    datos["usuarios"][nombre_clave] = texto
    guardar_datos_json(datos, ruta)
    return datos  # Para fines de impresión o depuración

def generar_clave_unica(ruta="datos.json"):
    datos = cargar_datos_json(ruta)
    contador = 1
    return f"usuario{contador}"

