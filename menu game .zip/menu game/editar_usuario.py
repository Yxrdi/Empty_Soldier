import json

# Cargar datos del JSON
def cargar_datos():
    with open('datos.json', 'r', encoding='utf-8') as archivo:
        datos = json.load(archivo)
    return datos

# Guardar datos en el JSON
def guardar_datos(datos):
    with open('datos.json', 'w', encoding='utf-8') as archivo:
        json.dump(datos, archivo, indent=4, ensure_ascii=False)

# Función principal
def main():
    datos = cargar_datos()
    
    # Guardar el valor de usuario1 en una variable
    valor_usuario = datos["usuarios"].get("usuario1")
    return valor_usuario
